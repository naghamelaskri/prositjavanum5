package tn.esprit.main;

import tn.esprit.entities.*;

public class Zoomanagement {

                public static void main(String[] args) {

                    Aquatic aquatic = new Aquatic("houta", "fish", 2, true, "Sea");
                    Terrestrial terrestrial = new Terrestrial("po", "fdf", 4, true, 2);
                    Dolphin dolphin = new Dolphin("Dem", "fg", 5, true, "trf", 14.5f);
                    Penguin penguin = new Penguin("tuue", "Sk", 3, true, "Ocean", 25.3f);


                    System.out.println(aquatic);
                    System.out.println(terrestrial);
                    System.out.println(dolphin);
                    System.out.println(penguin);

                    dolphin.swim();
                    penguin.swim();
                    aquatic.swim();
                }

}